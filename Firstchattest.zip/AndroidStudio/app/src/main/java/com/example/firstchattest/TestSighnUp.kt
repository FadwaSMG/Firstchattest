package com.example.firstchattest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class TestSighnUp : AppCompatActivity() {
    private lateinit var edtName: EditText
    private lateinit var edtEmail:EditText
    private lateinit var edtpasswd: EditText
    private lateinit var BtnSign1: Button
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_sighn_up)
        mAuth = FirebaseAuth.getInstance()
        edtName = findViewById(R.id.editname)
        edtEmail =findViewById(R.id.editEmail)
        edtpasswd = findViewById(R.id.editPasswd)
        BtnSign1 = findViewById(R.id.btnSignup1)
        BtnSign1.setOnClickListener {
            val Email= edtEmail.text.toString()
            val password=edtpasswd.text.toString()
            signUp(Email,password)
        }
    }
    private fun signUp(Email:String,password:String){
        //how the user will be created
        mAuth.createUserWithEmailAndPassword(Email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, jump to home activity
                    val intent=Intent(this@TestSighnUp, MainActivity::class.java)
                    startActivity(intent)

                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText( this@TestSighnUp, "Erreur!!!!!",Toast.LENGTH_SHORT).show()
                }
            }


    }

}